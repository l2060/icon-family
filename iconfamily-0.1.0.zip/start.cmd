@echo off
set PORT=3000
node --use-system-ca server\index.mjs
